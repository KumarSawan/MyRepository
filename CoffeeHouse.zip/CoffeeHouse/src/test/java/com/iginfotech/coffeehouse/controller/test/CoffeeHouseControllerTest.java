package com.iginfotech.coffeehouse.controller.test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.*;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

import com.iginfotech.coffeehouse.controller.CoffeeHouseController;
import com.iginfotech.coffeehouse.model.CustomerBean;
import com.iginfotech.coffeehouse.model.OrderBean;
import com.iginfotech.coffeehouse.model.ReportBean;
import com.iginfotech.coffeehouse.service.CoffeeHouseService;

@RunWith(MockitoJUnitRunner.class)
public class CoffeeHouseControllerTest {

	@Mock
	CoffeeHouseService coffeeHouseServiceMock;

	List<ReportBean> reportBeanMockList;
	Set<CustomerBean> customerBeanSet;

	@InjectMocks
	CoffeeHouseController coffeeHouseController;

	@Test()
	public void testAddCustomerDetails_1() throws Exception {
		CoffeeHouseController fixture = new CoffeeHouseController();
		fixture.coffeeHouseService = new CoffeeHouseService();
		String customerDetails = "{\r\n" + "\"custName\":\"sawan\",\r\n" + "\"phoneNumber\":\"8971957135\"\r\n" + "}";
		String result = fixture.addCustomerDetails(customerDetails);
		assertNotNull(result);
	}

	/**
	 * Run the String addCustomerDetails(String) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test(expected = org.json.JSONException.class)
	public void testAddCustomerDetails_2() throws Exception {
		CoffeeHouseController fixture = new CoffeeHouseController();
		fixture.coffeeHouseService = new CoffeeHouseService();
		String customerDetails = "";
		String result = fixture.addCustomerDetails(customerDetails);
		assertNotNull(result);
	}

	/**
	 * Run the String addNewCoffeeVarity(String) method test.
	 *
	 *
	 */
	@Test()
	public void testAddNewCoffeeVarity_1() throws Exception {
		CoffeeHouseController fixture = new CoffeeHouseController();
		fixture.coffeeHouseService = new CoffeeHouseService();
		String coffeeDetails = "{\r\n" + "\"coffeeName\":\"Latte\",\r\n" + "\"coffeeDescription\":\"BrewedCoffee\",\r\n"
				+ "\"servingsPerDay\":100\r\n" + "}";

		String result = fixture.addNewCoffeeVarity(coffeeDetails);
		assertNotNull(result);
	}

	/**
	 * Run the String addNewCoffeeVarity(String) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test(expected = org.json.JSONException.class)
	public void testAddNewCoffeeVarity_2() throws Exception {
		CoffeeHouseController fixture = new CoffeeHouseController();
		fixture.coffeeHouseService = new CoffeeHouseService();
		String coffeeDetails = "";
		String result = fixture.addNewCoffeeVarity(coffeeDetails);
		assertNotNull(result);
	}

	/**
	 * Run the List<ReportBean> generateReport() method test.
	 */
	@Test
	public void testGenerateReport_1() throws Exception {
		ReportBean reportBean = new ReportBean("Latte", 150, 25);
		reportBeanMockList.add(reportBean);
		List<ReportBean> resultFixture = coffeeHouseServiceMock.generateReport();
		assertEquals(1, resultFixture.size());
	}

	/**
	 * Run the List<ReportBean> generateReport() method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test
	public void testGenerateReport_2() throws Exception {
		ReportBean reportBean = new ReportBean("Latte", 150, 25);
		ReportBean reportBean1=new ReportBean("cappaccino", 150, 30);
		reportBeanMockList.add(reportBean);
		reportBeanMockList.add(reportBean1);
		List<ReportBean> result = coffeeHouseServiceMock.generateReport();
		assertNotNull(result);
		assertEquals(2, result.size());
	}

	/**
	 * Run the Set<CustomerBean> getAllCustomerDetails() method test.
	 *
	 */
	@Test
	public void testGetAllCustomerDetails_1() throws Exception {
	    CustomerBean custBean=new CustomerBean("sawan","8971957135");
	    CustomerBean custBean1=new CustomerBean("sawan","8971957135");
	    customerBeanSet.add(custBean);
	    customerBeanSet.add(custBean1);
	    Set<CustomerBean> result=coffeeHouseServiceMock.getAllCustomerDetails();
	    assertNotNull(result);
		assertEquals(1, result.size());
	    }

	/**
	 * Run the OrderBean processAnOrder(String) method test.
	 */
	@Test()
	public void testProcessAnOrder_1() throws Exception {
		CoffeeHouseController fixture = new CoffeeHouseController();
		fixture.coffeeHouseService = new CoffeeHouseService();
		String orderDetails = " {\r\n" + "\"custName\":\"sawan\",\r\n" + "\"phoneNumber\":\"8971957135\",\r\n"
				+ "\"coffee\":[{\"coffeeName\":\"Latte\",\r\n" + "\"quantity\":2},\r\n"
				+ "{\"coffeeName\":\"Cappuccino\",\r\n" + "\"quantity\":3}]\r\n" + "}";

		OrderBean result = fixture.processAnOrder(orderDetails);
		assertNotNull(result);
	}

	/**
	 * Run the OrderBean processAnOrder(String) method test.
	 *
	 * @throws Exception
	 */
	@Test(expected = org.json.JSONException.class)
	public void testProcessAnOrder_2() throws Exception {
		CoffeeHouseController fixture = new CoffeeHouseController();
		fixture.coffeeHouseService = new CoffeeHouseService();
		String orderDetails = "sachin";
		OrderBean result=fixture.processAnOrder(orderDetails);
		assertNotNull(result);
	}

	/**
	 * Perform pre-test initialization.
	 *
	 * @throws Exception
	 *             if the initialization fails for some reason
	 *
	 */
	@Before
	public void setUp() throws Exception {
		reportBeanMockList = new ArrayList<>();
		when(coffeeHouseServiceMock.generateReport()).thenReturn(reportBeanMockList);
		customerBeanSet=new HashSet<>();
		when(coffeeHouseServiceMock.getAllCustomerDetails()).thenReturn(customerBeanSet);
	}

	/**
	 * Perform post-test clean-up.
	 *
	 * @throws Exception
	 *             if the clean-up fails for some reason
	 *
	 */
	@After
	public void tearDown() throws Exception {
		// Add additional tear down code here
	}

	/**
	 * Launch the test.
	 *
	 * @param args
	 *            the command line arguments
	 *
	 *            //
	 */
	public static void main(String[] args) {
		new org.junit.runner.JUnitCore().run(CoffeeHouseControllerTest.class);
	}
}